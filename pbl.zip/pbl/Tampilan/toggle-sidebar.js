function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('hidden'); // Menambah atau menghapus kelas 'hidden' untuk sidebar
    document.querySelector('.main-content').classList.toggle('full-width'); // Menyesuaikan lebar konten utama
}

// Pilih tombol toggle dan elemen sidebar
const toggleBtn = document.getElementById('toggle-btn');
const sidebar = document.querySelector('.sidebar');

toggleBtn.addEventListener('click', function () {
    sidebar.classList.toggle('hidden'); // Tambahkan/hapus class "hidden" untuk sidebar
    document.querySelector('.main-content').classList.toggle('full-width'); // Sesuaikan main-content
});
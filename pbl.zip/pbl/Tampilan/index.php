<!doctype html> 
<html lang="en" data-bs-theme="auto">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>San Sigma - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
    <script src="toggle-sidebar.js" defer></script> <!-- Pastikan JS dipanggil setelah elemen-elemen HTML -->
</head>
<body>
    <div class="sidebar">
        <div class="logo">
            <h1>
                <img src="/pbl/Sysmbol/SanSigma.png" alt="San Sigma Logo">
                San Sigma
            </h1>
        </div>
        <nav>
            <ul>
                <li class="profile-item">
                    <img src="/pbl/Sysmbol/Group1.png" alt="Dashboard">
                    <a href="#" class="active">Dashboard</a>
                </li>
                <li class="profile-item">
                    <img src="/pbl/Sysmbol/Vector1.png" alt="Input Prestasi">
                    <a href="#">Input Prestasi</a>
                </li>
                <li class="profile-item">
                    <img src="/pbl/Sysmbol/Vector2.png" alt="Riwayat">
                    <a href="#">Riwayat</a>
                </li>
                <li class="profile-item">
                    <img src="/pbl/Sysmbol/Group2.png" alt="Profile">
                    <a href="#">Profile</a>
                </li>
                <li class="logout" >
                    <img src="/pbl/Sysmbol/Exit.png" alt="Keluar">
                    <a href="#">Keluar</a> 
                </li> 
            </ul>
        </nav>
    </div>

    <div class="main-content">
        <div class="Baseline">
            <button id="toggle-btn" class="toggle-btn">
            <img src="/pbl/Sysmbol/Baseline.png" alt="Notification">
            </button>
            <div class="right-content">
                <img src="/pbl/Sysmbol/Notif.png" alt="Notification">
                <div class="vertical-line"></div>
                <img src="/pbl/Sysmbol/Profil.png" alt="User Avatar">

                <div class="profile-details">
                    <span href="#" class="name">Budi Arie</span>
                    <span class="number">234156279283</span>
                </div>
            </div>
</div>
        <header>
            <h1>
                <a href="#" class="text-abu2">Mahasiswa</a>
                <a href="#" class="text-biru"> / Dashboard</a>
            </h1>
        </header>

        <section class="dashboard">
            <div class="card">
                <h3>Penghargaan Yang Belum Diverifikasi
                    <img src="/pbl/Sysmbol/Silang.png" class="VerifSimbol" alt="Belum Verifikasi">
                </h3>
                <div class="dashboard horizontal-align">
                    <img src="/pbl/Sysmbol/Verif1.png" class="Verif1" alt="Jumlah Belum Verifikasi">
                    <p class="verification-count">3</p>
                </div>
                <a href="#" class="responsive-button">Lihat Detail &gt;</a>
            </div>

            <div class="card">
                <h3>Sudah Diverifikasi
                    <img src="/pbl/Sysmbol/Centang.png" class="VerifSimbol" alt="Sudah Verifikasi">
                </h3>
                <div class="dashboard horizontal-align">
                    <img src="/pbl/Sysmbol/Verif2.png" class="Verif2" alt="Jumlah Sudah Verifikasi">
                    <p class="verification-count">3</p>
                </div>
                <a href="#">Lihat Detail &gt;</a>
</div>
            <div class="card">
                <h3>Skor Saya</h3>
                <p style="font: 30px; font-weight: bold;">3005</p>
                <div class="score-wrapper">
                    <img src="/pbl/Sysmbol/Icon2.png" class="Icon2" alt="Skor" style="margin-top: -5px;">
                </div>
                <a href="#">Lihat Detail &gt;</a>
            </div>

            <div class="card">
                <h3>Top 10
                    <img src="/pbl/Sysmbol/AktifVector1.png" class="AktifVector1">
                    <img src="/pbl/Sysmbol/AktifVector2.png" class="AktifVector2">
                </h3>
                <h3>Mahasiswa Paling Aktif</h3>
                <div class="score-wrapper">
                    <img src="/pbl/Sysmbol/Icon1.png" class="Icon1" alt="Mahasiswa Aktif" style="margin-top: -5px">
                </div>
                <a href="#">Lihat Detail &gt;</a>
            </div>
        </section>
    </div>
</body>

</html>
